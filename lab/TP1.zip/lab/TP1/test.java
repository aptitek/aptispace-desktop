package lab.TP1;

public class test {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
